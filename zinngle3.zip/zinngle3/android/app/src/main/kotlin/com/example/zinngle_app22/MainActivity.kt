package com.example.zinngle_app22

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
