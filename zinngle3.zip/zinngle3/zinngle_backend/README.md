# Zinngle Backend

Backend API for the Zinngle Wallet application, built with Spring Boot.

## Overview

Zinngle Backend provides secure, scalable REST APIs for user authentication, profile management, matchmaking, chat, video calls, notifications, and more.

It integrates PostgreSQL, Firebase, and third-party services providing real-time and payment capabilities.

## Features

- User management and authentication (JWT + Firebase)
- Matchmaking with swipe and discovery support
- Real-time chat and video call support
- Push notifications via Firebase Cloud Messaging
- Admin APIs and moderation features
- Scheduled tasks for cleanup and analytics
- Swagger/OpenAPI documentation

## Getting Started

### Prerequisites

- Java 17+
- Maven 3.8+
- PostgreSQL database
- Docker (optional for containerized deployment)

### Build & Run