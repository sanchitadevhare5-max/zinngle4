#!/bin/bash

set -e

# Navigate to the project root directory
PROJECT_ROOT=$(dirname "$0")/..

echo "Building zinngle-backend application..."

cd "$PROJECT_ROOT"

# Clean previous builds
./gradlew clean

# Build the fat jar
./gradlew bootJar

echo "Build completed. Jar located at build/libs/"

# Optionally, build docker image
echo "Building Docker image..."

docker build -t zinngle/zinngle-backend:latest -f docker/Dockerfile .

echo "Docker image built with tag zinngle/zinngle-backend:latest"