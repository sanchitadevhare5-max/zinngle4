#!/bin/bash

set -e

# Variables to configure deployment
DOCKER_IMAGE="zinngle/zinngle-backend:latest"
CONTAINER_NAME="zinngle-backend"
DOCKER_COMPOSE_FILE="docker/docker-compose.yml"

echo "Starting deployment of zinngle-backend..."

# Pull latest image (if using remote registry)
docker pull $DOCKER_IMAGE || echo "Local image will be used as pull failed."

# Stop existing container if running
if docker ps -q -f name=$CONTAINER_NAME; then
  echo "Stopping existing container..."
  docker stop $CONTAINER_NAME
  docker rm $CONTAINER_NAME
fi

# Start containers with docker-compose
echo "Starting containers using docker-compose..."
docker-compose -f $DOCKER_COMPOSE_FILE up -d --build

echo "Deployment completed successfully."