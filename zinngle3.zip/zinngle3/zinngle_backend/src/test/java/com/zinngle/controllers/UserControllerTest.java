package com.zinngle.controllers;

import com.google.firebase.remoteconfig.internal.TemplateResponse.UserResponse;
import com.zinngle.controller.UserController;
import com.zinngle.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetUserProfile_success() {
        String userId = "12345";
        UserResponse mockResponse = new UserResponse();
        mockResponse.setId(userId);
        mockResponse.setName("John");
        mockResponse.setName("Doe");
        mockResponse.setEmail("john.doe@example.com");

        when(userService.getUserById(userId)).thenReturn(mockResponse);

        ResponseEntity<UserResponse> response = userController.getUserProfile(userId);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(userId, response.getBody().getId());
        assertEquals("John", response.getBody().getFirstName());
    }

    // Additional tests for update, delete, list etc.
}
