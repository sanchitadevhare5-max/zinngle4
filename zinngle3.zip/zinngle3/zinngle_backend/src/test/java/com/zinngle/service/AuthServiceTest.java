package com.zinngle.service;

import com.zinngle.dto.AuthRequest;
import com.zinngle.dto.AuthResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class AuthServiceTest {

    @InjectMocks
    private AuthService authService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLogin_success() {
        AuthRequest request = new AuthRequest();
        request.setEmail("john@example.com");
        request.setPassword("password123");

        // Assuming authService.login returns a token string or response
        String token = authService.login(request.getEmail(), request.getPassword());

        assertNotNull(token);
        // Further assertions for token format, claims etc.
    }

    // Additional tests for registration, logout, refresh token
}

