package com.zinngle.repository;

import com.zinngle.model.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testSaveAndFindUser() {
        User user = User.builder()
                .id("user-123")
                .firstName("Test")
                .lastName("User")
                .email("testuser@example.com")
                .build();

        userRepository.save(user);

        Optional<User> found = userRepository.findById("user-123");
        assertThat(found).isPresent();

        User foundUser = found.get();
        assertThat(foundUser.getEmail()).isEqualTo("testuser@example.com");
    }

    @Test
    public void testFindByEmail() {
        User user = User.builder()
                .id("user-456")
                .firstName("Another")
                .lastName("User")
                .email("anotheruser@example.com")
                .build();

        userRepository.save(user);

        Optional<User> found = userRepository.findByEmail("anotheruser@example.com");
        assertThat(found).isPresent();

        User foundUser = found.get();
        assertThat(foundUser.getId()).isEqualTo("user-456");
    }
}
