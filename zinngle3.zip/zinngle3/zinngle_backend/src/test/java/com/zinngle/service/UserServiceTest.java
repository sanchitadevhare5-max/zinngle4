package com.zinngle.service;

import com.zinngle.model.User;
import com.zinngle.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        testUser = User.builder()
                .id("user123")
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .build();
    }

    @Test
    void testGetUserById_found() {
        when(userRepository.findById("user123")).thenReturn(Optional.of(testUser));

        User user = userService.getUserById("user123");

        assertNotNull(user);
        assertEquals("John", user.getFirstName());
        verify(userRepository, times(1)).findById("user123");
    }

    @Test
    void testGetUserById_notFound() {
        when(userRepository.findById("user999")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            userService.getUserById("user999");
        });

        verify(userRepository, times(1)).findById("user999");
    }

    // Add more tests for create, update, delete etc.
}

