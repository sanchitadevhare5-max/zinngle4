package com.zinngle.integration;

public class testUser {

}
