package com.zinngle.repository;

import com.zinngle.model.entity.Match;
import com.zinngle.model.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class MatchRepositoryTest {

    @Autowired
    private MatchRepository matchRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testFindByUserId() {
        User user = User.builder()
                .id("user1")
                .firstName("John")
                .lastName("Smith")
                .email("john@example.com")
                .build();
        userRepository.save(user);

        User matchedUser = User.builder()
                .id("user2")
                .firstName("Jane")
                .lastName("Doe")
                .email("jane@example.com")
                .build();
        userRepository.save(matchedUser);

        Match match = Match.builder()
                .id("match1")
                .user(user)
                .matchedUser(matchedUser)
                .matchedAt(LocalDateTime.now())
                .active(true)
                .build();
        matchRepository.save(match);

        List<Match> matches = matchRepository.findByUserId("user1");
        assertThat(matches).isNotEmpty();
        assertThat(matches.get(0).getMatchedUser().getEmail()).isEqualTo("jane@example.com");
    }
}
