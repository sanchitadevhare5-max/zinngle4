package com.zinngle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// Runs the full Spring Boot context for integration testing
@SpringBootTest
class ZinngleApplicationTests {

    @Test
    void contextLoads() {
        // Verifies that application context starts successfully
    }
}