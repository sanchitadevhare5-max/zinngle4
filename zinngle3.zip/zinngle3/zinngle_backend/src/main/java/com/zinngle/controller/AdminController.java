package com.zinngle.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.AdminService;
import com.zinngle.dto.AdminUserResponse;

// Admin dashboard APIs
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    @Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/users")
    public ResponseEntity<List<AdminUserResponse>> listUsers(
        @RequestParam(required = false) String filter,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "20") int size) {
        
        List<AdminUserResponse> users = adminService.listUsers(filter, page, size);
        return ResponseEntity.ok(users);
    }

    @PostMapping("/users/{userId}/deactivate")
    public ResponseEntity<Void> deactivateUser(@PathVariable String userId) {
        adminService.deactivateUser(userId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/users/{userId}/reactivate")
    public ResponseEntity<Void> reactivateUser(@PathVariable String userId) {
        adminService.reactivateUser(userId);
        return ResponseEntity.noContent().build();
    }
}