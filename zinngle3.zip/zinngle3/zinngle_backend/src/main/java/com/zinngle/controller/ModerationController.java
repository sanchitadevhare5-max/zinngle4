package com.zinngle.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.ModerationService;
import com.zinngle.dto.ModerationRequest;
import com.zinngle.dto.ModerationResponse;

// Safety and moderation related endpoint
@RestController
@RequestMapping("/api/moderation")
public class ModerationController {

    private final ModerationService moderationService;

    @Autowired
    public ModerationController(ModerationService moderationService) {
        this.moderationService = moderationService;
    }

    @PostMapping("/report")
    public ResponseEntity<ModerationResponse> reportUser(@RequestBody ModerationRequest request) {
        ModerationResponse response = moderationService.reportUser(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/block")
    public ResponseEntity<Void> blockUser(@RequestParam String userId, @RequestParam String blockedUserId) {
        moderationService.blockUser(userId, blockedUserId);
        return ResponseEntity.noContent().build();
    }
}
