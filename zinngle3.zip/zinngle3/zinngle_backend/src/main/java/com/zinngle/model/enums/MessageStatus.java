package com.zinngle.enums;

public enum MessageStatus {
    SENT,
    DELIVERED,
    SEEN
}