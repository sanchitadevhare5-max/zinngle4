package com.zinngle.dto;

import lombok.Data;

import javax.validation.constraints.Min;

@Data
public class DiscoveryRequest {

    private String userId;

    private String filter;     // e.g. location, interests

    @Min(value = 0, message = "Page number cannot be negative")
    private int page = 0;

    @Min(value = 1, message = "Page size must be at least 1")
    private int size = 20;
}
