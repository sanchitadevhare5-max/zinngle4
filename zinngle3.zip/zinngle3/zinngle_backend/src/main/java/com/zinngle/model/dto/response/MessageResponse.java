package com.zinngle.dto.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MessageResponse {

    private String messageId;

    private String conversationId;

    private String senderId;

    private String receiverId;

    private String content;

    private LocalDateTime sentAt;

    private Boolean read;

    // Additional fields like attachment URLs, message type, etc.
}
