package com.zinngle.dto.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MatchResponse {

    private String matchId;

    private String userId;

    private String matchedUserId;

    private LocalDateTime matchedAt;

    private Boolean active;

    // Additional fields like compatibility score, etc.
}

