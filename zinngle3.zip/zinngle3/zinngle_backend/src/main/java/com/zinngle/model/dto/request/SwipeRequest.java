package com.zinngle.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SwipeRequest {

    @NotBlank(message = "User ID is required")
    private String userId;

    @NotBlank(message = "Target user ID is required")
    private String targetUserId;

    @NotNull(message = "Swipe action is required")
    private Boolean liked;
}

