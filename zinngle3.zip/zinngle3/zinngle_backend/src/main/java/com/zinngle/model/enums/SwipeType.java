package main.java.com.zinngle.model.enums;

public enum SwipeType {
    LIKE,
    PASS
}
