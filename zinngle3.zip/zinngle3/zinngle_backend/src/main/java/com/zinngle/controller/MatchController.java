package com.zinngle.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.MatchService;
import com.zinngle.dto.MatchResponse;

// Endpoint for managing matches
@RestController
@RequestMapping("/api/matches")
public class MatchController {

    private final MatchService matchService;

    @Autowired
    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @GetMapping("/")
    public ResponseEntity<List<MatchResponse>> getMatches(@RequestParam String userId) {
        List<MatchResponse> matches = matchService.getMatchesForUser(userId);
        return ResponseEntity.ok(matches);
    }
}
