package com.zinngle.exception;

public class AuthenticationException extends ZinngleException {
    private static final String DEFAULT_CODE = "AUTHENTICATION_ERROR";

    public AuthenticationException(String message) {
        super(message, DEFAULT_CODE);
    }

    public AuthenticationException(String message, Throwable cause) {
        super(message, DEFAULT_CODE, cause);
    }
}