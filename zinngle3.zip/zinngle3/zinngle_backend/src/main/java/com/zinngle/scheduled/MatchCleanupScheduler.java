package com.zinngle.scheduled;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled task to clean up old/inactive matches.
 */
@Component
public class MatchCleanupScheduler {

    private static final Logger logger = LoggerFactory.getLogger(MatchCleanupScheduler.class);

    // Run every day at 2 AM
    @Scheduled(cron = "0 0 2 * * *")
    public void cleanUpOldMatches() {
        logger.info("Running scheduled task: cleanUpOldMatches");
        // TODO: Implement logic to remove or archive matches that are no longer active,
        // older than certain retention period.
    }
}
