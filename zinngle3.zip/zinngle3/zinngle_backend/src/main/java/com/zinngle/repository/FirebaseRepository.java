package com.repository;

import org.springframework.stereotype.Repository;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Base repository class for Firebase Database operations.
 * Extend this class for specific Firebase operations.
 */
@Repository
public class FirebaseRepository {
    protected final FirebaseDatabase firebaseDatabase;
    protected final DatabaseReference rootRef;

    public FirebaseRepository() {
        firebaseDatabase = FirebaseDatabase.getInstance();
        rootRef = firebaseDatabase.getReference();
    }

    // Common Firebase Database helper methods

    protected DatabaseReference getRef(String path) {
        return rootRef.child(path);
    }
    
    // Additional reusable methods for push, update, delete, query, etc.
}