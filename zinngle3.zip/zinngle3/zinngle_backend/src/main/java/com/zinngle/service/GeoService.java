package com.service;

import org.springframework.stereotype.Service;

@Service
public class GeoService {

    public Location getUserLocation(String userId) {
        // Return last known user location or fetch fresh one
        return new Location();
    }

    public double calculateDistance(Location loc1, Location loc2) {
        // Calculate geographic distance between two coordinates
        return 0.0;
    }
  
    // Geospatial queries and logic
}