package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.model.Swipe;

import java.util.List;

@Repository
public interface SwipeRepository extends JpaRepository<Swipe, String> {
    
    List<Swipe> findByUserId(String userId);
    
    List<Swipe> findByTargetUserId(String targetUserId);
    
    // Additional query methods if needed
}
