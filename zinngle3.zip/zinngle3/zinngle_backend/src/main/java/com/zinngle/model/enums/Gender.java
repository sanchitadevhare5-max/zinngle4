package com.zinngle.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER,
    UNDISCLOSED
}
