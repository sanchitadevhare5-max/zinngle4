package com.zinngle.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.ChatService;
import com.zinngle.dto.ChatMessageRequest;
import com.zinngle.dto.ChatMessageResponse;

// Chat and messaging endpoints
@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatService chatService;

    @Autowired
    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping("/send")
    public ResponseEntity<ChatMessageResponse> sendMessage(@RequestBody ChatMessageRequest request) {
        ChatMessageResponse message = chatService.sendMessage(request);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/conversations/{userId}")
    public ResponseEntity<List<ChatMessageResponse>> getConversations(@PathVariable String userId) {
        List<ChatMessageResponse> conversations = chatService.getConversations(userId);
        return ResponseEntity.ok(conversations);
    }
}