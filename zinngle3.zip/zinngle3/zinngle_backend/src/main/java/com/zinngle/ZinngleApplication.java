package com.zinngle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZinngleApplication {
    public static void main(String[] args) {
        SpringApplication.run(ZinngleApplication.class, args);
    }
}