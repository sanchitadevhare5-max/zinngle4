package com.zinngle.validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator for geographic coordinates.
 */
public class LocationValidator implements ConstraintValidator<ValidLocation, Location> {

    @Override
    public void initialize(ValidLocation constraintAnnotation) {
        // No initialization needed
    }

    @Override
    public boolean isValid(Location location, ConstraintValidatorContext context) {
        if(location == null) {
            return false;
        }
        // Assuming Location has getLatitude() and getLongitude()
        Double lat = location.getLatitude();
        Double lng = location.getLongitude();

        if (lat == null || lng == null) {
            return false;
        }
        return lat >= -90.0 && lat <= 90.0 && lng >= -180.0 && lng <= 180.0;
    }
}
