package com.zinngle.exception;

public class UserNotFoundException extends ZinngleException {
    private static final String DEFAULT_CODE = "USER_NOT_FOUND";

    public UserNotFoundException(String userId) {
        super("User not found with ID: " + userId, DEFAULT_CODE);
    }

    public UserNotFoundException(String userId, Throwable cause) {
        super("User not found with ID: " + userId, DEFAULT_CODE, cause);
    }
}