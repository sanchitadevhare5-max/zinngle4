package com.service;

import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ChatService {

    public ChatMessage sendMessage(ChatMessage message) {
        // Save message, notify recipient
        return message;
    }

    public List<ChatMessage> getMessages(String conversationId) {
        // Fetch chat history
        return List.of();
    }
  
    // Chat related business logic
}
