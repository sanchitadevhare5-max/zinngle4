package com.zinngle.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.SwipeService;
import com.zinngle.dto.SwipeRequest;
import com.zinngle.dto.SwipeResponse;

// Endpoints handling swipe actions
@RestController
@RequestMapping("/api/swipe")
public class SwipeController {

    private final SwipeService swipeService;

    @Autowired
    public SwipeController(SwipeService swipeService) {
        this.swipeService = swipeService;
    }

    @PostMapping("/")
    public ResponseEntity<SwipeResponse> swipe(@RequestBody SwipeRequest request) {
        SwipeResponse response = swipeService.handleSwipe(request);
        return ResponseEntity.ok(response);
    }
}