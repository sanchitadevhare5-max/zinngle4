package com.zinngle.dto.response;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class UserResponse {

    private String id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String profilePhotoUrl;
    private String bio;

    private LocalDateTime dateOfBirth;
    private String city;
    private String country;

    private List<String> interests;

    private Boolean verified;
    private Boolean active;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Additional fields as per user profile requirements
}
