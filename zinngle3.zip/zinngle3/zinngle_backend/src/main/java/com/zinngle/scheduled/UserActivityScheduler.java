package com.zinngle.scheduled;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled task to update user activity statuses.
 */
@Component
public class UserActivityScheduler {

    private static final Logger logger = LoggerFactory.getLogger(UserActivityScheduler.class);

    // Run every 5 minutes
    @Scheduled(cron = "0 */5 * * * *")
    public void updateUserActivity() {
        logger.info("Running scheduled task: updateUserActivity");
        // TODO: Implement logic to update user last active timestamps,
        // handle sessions, detect inactive users, etc.
    }
}