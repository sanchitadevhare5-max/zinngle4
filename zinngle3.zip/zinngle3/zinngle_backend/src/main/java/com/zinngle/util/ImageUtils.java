package com.zinngle.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;

public class ImageUtils {

    /**
     * Resize an image to specified width and height.
     *
     * @param imageData image bytes
     * @param width desired width
     * @param height desired height
     * @return resized image bytes
     */
    public static byte[] resizeImage(byte[] imageData, int width, int height) throws Exception {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(imageData)) {
            BufferedImage originalImage = ImageIO.read(bais);
            BufferedImage resizedImage = new BufferedImage(width, height, originalImage.getType());

            resizedImage.getGraphics().drawImage(originalImage, 0, 0, width, height, null);

            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                ImageIO.write(resizedImage, "jpg", baos);
                return baos.toByteArray();
            }
        }
    }

    // Additional image related helpers (compression, cropping, format conversion)

}

