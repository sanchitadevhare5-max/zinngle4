package com.zinngle.util;

import java.util.Objects;

public class GeoUtils {

    private static final double EARTH_RADIUS_KM = 6371.0;

    /**
     * Calculate distance between two geographic coordinates using Haversine formula.
     *
     * @param lat1 latitude of first point in degrees
     * @param lon1 longitude of first point in degrees
     * @param lat2 latitude of second point in degrees
     * @param lon2 longitude of second point in degrees
     * @return distance in kilometers
     */
    public static double calculateDistanceKm(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return EARTH_RADIUS_KM * c;
    }

    /**
     * Validate latitude value.
     *
     * @param latitude value to validate
     * @return true if valid latitude, else false
     */
    public static boolean isValidLatitude(Double latitude) {
        return Objects.nonNull(latitude) && latitude >= -90.0 && latitude <= 90.0;
    }

    /**
     * Validate longitude value.
     *
     * @param longitude value to validate
     * @return true if valid longitude, else false
     */
    public static boolean isValidLongitude(Double longitude) {
        return Objects.nonNull(longitude) && longitude >= -180.0 && longitude <= 180.0;
    }

    // Additional geolocation helper methods can be added here

}