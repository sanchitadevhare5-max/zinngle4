package com.zinngle.exception;

public class InvalidSwipeException extends ZinngleException {
    private static final String DEFAULT_CODE = "INVALID_SWIPE";

    public InvalidSwipeException(String message) {
        super(message, DEFAULT_CODE);
    }

    public InvalidSwipeException(String message, Throwable cause) {
        super(message, DEFAULT_CODE, cause);
    }
}
