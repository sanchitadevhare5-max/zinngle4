
package com.zinngle.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AgoraConfig {

    @Value("${agora.app.id}")
    private String appId;

    @Value("${agora.app.certificate}")
    private String appCertificate;

    // Getters
    public String getAppId() {
        return appId;
    }

    public String getAppCertificate() {
        return appCertificate;
    }

    // Additional beans or configuration for Agora SDK initialization can be added here
}
