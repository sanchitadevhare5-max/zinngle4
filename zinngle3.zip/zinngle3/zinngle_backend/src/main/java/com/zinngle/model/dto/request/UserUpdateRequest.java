package com.zinngle.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserUpdateRequest {

    @Size(max = 50, message = "First name too long")
    private String firstName;

    @Size(max = 50, message = "Last name too long")
    private String lastName;

    private String phoneNumber;

    private String bio;

    private String city;

    private String country;

    // Additional profile fields as needed
}
