package com.zinngle.util;

import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Notification;
import java.util.concurrent.CompletableFuture;

public class NotificationUtils {

    private static final FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();

    /**
     * Send a push notification to a specific device token.
     *
     * @param token device FCM token
     * @param title notification title
     * @param body notification body
     * @return CompletableFuture for async send operation
     */
    public static CompletableFuture<String> sendPushNotification(String token, String title, String body) {
        Notification notification = Notification.builder()
            .setTitle(title)
            .setBody(body)
            .build();

        Message message = Message.builder()
            .setToken(token)
            .setNotification(notification)
            .build();

        return firebaseMessaging.sendAsync(message);
    }

    // Helper methods for topic/fanout notifications, data payloads, etc.
}