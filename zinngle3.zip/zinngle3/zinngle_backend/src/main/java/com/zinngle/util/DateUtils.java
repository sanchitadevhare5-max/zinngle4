package com.zinngle.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    private static final DateTimeFormatter ISO_FORMATTER = DateTimeFormatter.ISO_DATE_TIME;

    /**
     * Format a LocalDateTime to ISO 8601 string.
     *
     * @param dateTime the LocalDateTime
     * @return formatted ISO 8601 string
     */
    public static String toIsoString(LocalDateTime dateTime) {
        return dateTime.format(ISO_FORMATTER);
    }

    /**
     * Parse ISO 8601 string to LocalDateTime.
     *
     * @param isoDateString ISO 8601 date string
     * @return parsed LocalDateTime
     */
    public static LocalDateTime fromIsoString(String isoDateString) {
        return LocalDateTime.parse(isoDateString, ISO_FORMATTER);
    }

    // Additional date/time utilities such as relative time formatting, timezone conversions, pocket-friendly formats, etc.

}

