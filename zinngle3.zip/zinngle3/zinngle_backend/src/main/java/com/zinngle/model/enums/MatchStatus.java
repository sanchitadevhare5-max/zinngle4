package com.zinngle.enums;

public enum MatchStatus {
    ACTIVE,
    BLOCKED,
    DELETED
}
