package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.model.Match;

import java.util.List;

@Repository
public interface MatchRepository extends JpaRepository<Match, String> {
    
    List<Match> findByUserId(String userId);
    
    List<Match> findByMatchId(String matchId);
    
    // Additional query methods to support match retrieval
}