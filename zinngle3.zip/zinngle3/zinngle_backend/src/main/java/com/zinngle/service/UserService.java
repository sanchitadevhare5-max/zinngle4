package com.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    public User getUserById(String id) {
        // Fetch user info from database
        return new User();
    }

    public void updateUser(User user) {
        // Update user info in database
    }

    public void deleteUser(String id) {
        // Delete user data
    }
  
    // User profile related business logic
    // e.g., preferences, settings, profile photo update
}