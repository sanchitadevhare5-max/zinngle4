package com.zinngle.dto.response;

import lombok.Data;

@Data
public class AuthResponse {

    private String userId;
    private String accessToken;
    private String refreshToken;
    private Long expiresIn;  // seconds

    private String tokenType = "Bearer";

    private String message;  // optional, success or error message
}

