package com.zinngle.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.service.VideoService;
import com.zinngle.dto.VideoCallRequest;
import com.zinngle.dto.VideoCallResponse;

// Video call management endpoints
@RestController
@RequestMapping("/api/video")
public class VideoController {

    private final VideoService videoService;

    @Autowired
    public VideoController(VideoService videoService) {
        this.videoService = videoService;
    }

    @PostMapping("/call")
    public ResponseEntity<VideoCallResponse> initiateCall(@RequestBody VideoCallRequest request) {
        VideoCallResponse response = videoService.initiateCall(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/end")
    public ResponseEntity<Void> endCall(@RequestParam String callId) {
        videoService.endCall(callId);
        return ResponseEntity.noContent().build();
    }
}