package com.zinngle.exception;

public class MatchNotFoundException extends ZinngleException {
    private static final String DEFAULT_CODE = "MATCH_NOT_FOUND";

    public MatchNotFoundException(String matchId) {
        super("Match not found with ID: " + matchId, DEFAULT_CODE);
    }

    public MatchNotFoundException(String matchId, Throwable cause) {
        super("Match not found with ID: " + matchId, DEFAULT_CODE, cause);
    }
}
