package com.zinngle.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zinngle.dto.UserProfileResponse;
import com.zinngle.service.DiscoveryService;

// Endpoints for user discovery and browsing
@RestController
@RequestMapping("/api/discovery")
public class DiscoveryController {

    private final DiscoveryService discoveryService;

    @Autowired
    public DiscoveryController(DiscoveryService discoveryService) {
        this.discoveryService = discoveryService;
    }

    @GetMapping("/users")
    public ResponseEntity<List<UserProfileResponse>> discoverUsers(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "20") int size,
        @RequestParam(required = false) String filter) {
        
        List<UserProfileResponse> results = discoveryService.discoverUsers(page, size, filter);
        return ResponseEntity.ok(results);
    }
}