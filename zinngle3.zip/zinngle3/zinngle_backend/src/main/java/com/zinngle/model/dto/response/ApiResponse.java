package com.zinngle.dto.response;

import lombok.Data;

@Data
public class ApiResponse<T> {

    private Boolean success;
    private String message;
    private T data;

    public ApiResponse() {}

    public ApiResponse(Boolean success, String message, T data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }

    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(true, "Request succeeded", data);
    }

    public static <T> ApiResponse<T> failure(String message) {
        return new ApiResponse<>(false, message, null);
    }
}
